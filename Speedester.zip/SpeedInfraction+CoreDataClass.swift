//
//  SpeedInfraction+CoreDataClass.swift
//  Speedster
//
//  Created by Hasnain Bilgrami on 11/1/16.
//  Copyright © 2016 Hasnain Bilgrami. All rights reserved.
//

import Foundation
import CoreData


public class SpeedInfraction: NSManagedObject {

}
